const express = require("express");
const ytdl = require("ytdl-core");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.static("public"));

app.get("/download", async (req, res) => {
  const videoURL = req.query.url;
  if (!videoURL || !ytdl.validateURL(videoURL)) {
    return res.status(400).send("Invalid YouTube URL");
  }
  try {
    const info = await ytdl.getInfo(videoURL);
    const title = info.videoDetails.title.replace(/[\\/:"*?<>|]+/g, "");
    res.header("Content-Disposition", `attachment; filename="${title}.mp4"`);
    ytdl(videoURL, { filter: format => format.container === 'mp4' }).pipe(res);
  } catch (err) {
    console.error(err);
    res.status(500).send("Error downloading video");
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
